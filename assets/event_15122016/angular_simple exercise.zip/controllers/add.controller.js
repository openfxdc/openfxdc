sampleApp.controller('addController', function($scope, ContactService, $location, $routeParams) {

  if ($routeParams.contactId) {
    $scope.newcontact = angular.copy(ContactService.getContact($routeParams.contactId));
  }
  

  //$scope.contactsLen = ContactService.getContacts().length;

  $scope.saveContact = function() {
    //write your code here
  }

  

});

