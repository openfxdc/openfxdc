sampleApp.controller('detailsController', function($scope, $routeParams, ContactService) {
  $scope.order_id = $routeParams.orderId;
  $scope.details = ContactService.getContact($scope.order_id);

  $scope.delete = function(id) {
	//your code here
  }

});