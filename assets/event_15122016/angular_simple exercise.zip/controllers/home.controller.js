sampleApp.controller('homeController', function($scope, $routeParams, ContactService) {

	//get contacts here
  $scope.contactsHome = ContactService.getContacts();

});
