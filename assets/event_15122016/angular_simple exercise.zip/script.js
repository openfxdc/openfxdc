// Code goes here
var sampleApp = angular.module('sampleApp', []);

sampleApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'templates/home.view.html',
        controller: 'homeController'
      })
      .when('/ShowOrder/:orderId', {
        templateUrl: 'templates/details.view.html',
        controller: 'detailsController'
      })
      .when('/add', {
        templateUrl: 'templates/add.view.html',
        controller: 'addController'
      })
      .when('/edit/:contactId', {
        templateUrl: 'templates/add.view.html',
        controller: 'addController'
      });
  }
]);



