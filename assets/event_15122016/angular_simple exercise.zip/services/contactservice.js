sampleApp.service('ContactService', function() {
  //to create unique contact id
  var uid = 1;

  //contacts array to hold list of all contacts
  var contacts = [{
    id: 0,
    'name': 'Shahenshah',
    'email': 'hello@gmail.com',
    'phone': '123-2343-44'
  }];

  //save method create a new contact if not already exists
  //else update the existing object
  this.save = function(contact) {
    if(contact.id == 0){
      contacts[0] = contact;
    }
    else if (!contact.id) {
      //if this is new contact, add it in contacts array
      contact.id = uid++;
      contacts.push(contact);
    } else {
      //for existing contact, find this contact using id
      //and update it.
      for (i in contacts) {
        if (contacts[i].id == contact.id) {
          contacts[i] = contact;
        }
      }
    }

  }

  //simply search contacts list for given id
  //and returns the contact object if found
  this.getContact = function(id) {
    for (i in contacts) {
      if (contacts[i].id == id) {
        return contacts[i];
      }
    }

  }

  //iterate through contacts list and delete 
  //contact if found
  this.delete = function(id) {
    for (i in contacts) {
      if (contacts[i].id == id) {
        contacts.splice(i, 1);
      }
    }
  }

  //simply returns the contacts list
  this.getContacts = function() {
    return contacts;
  }
});